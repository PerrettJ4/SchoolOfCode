
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'perrettj4',
  applicationName: 'aws-node-http-api-project',
  appUid: 'bxN4bs4q5rW9CVWjN2',
  orgUid: '7a789c30-a4a1-491f-876f-b9cb4743e29f',
  deploymentUid: 'a691bdac-0875-4df5-a6cf-bccc3b752dc0',
  serviceName: 'aws-node-http-api-project',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-node-http-api-project-dev-item', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getItemById, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}